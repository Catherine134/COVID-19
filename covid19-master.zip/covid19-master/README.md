# covid19
SIR code in python to model the spread of COVID-19
